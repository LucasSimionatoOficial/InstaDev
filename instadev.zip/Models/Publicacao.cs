using System.Collections.Generic;
using System.IO;
using instadev.Interface;

namespace instadev.Models
{
    public class Publicacao : InstadevBase, IPublicacao
    {
        public int IdPublicacao { get; set; }
        public string Imagem { get; set; }
        public string Legenda { get; set; }
        public int IdUsuario { get; set; }
        public int NumeroLikes { get; set; }
        public List<int> Likes { get; set; }
        private string PATH = "Database/Publicacoes";
        //Organizaxao do csv: IdPublicacao;Imagem;Legenda;IdUsuario;NumeroLikes;Likes
        //Likes idlike1/idlike2...

        //Usar a barra como separador para saber quem deu o like; idlike = id de alguem que deu like
        Publicacao()
        {
            CreateFolderAndFile(PATH);
        }
        private string Prepare(Publicacao publicacao)
        {
            string likes_ = "";
            bool likes = false;
            foreach (var item in publicacao.Likes)
            {
                if (likes)
                {
                    likes_ += $"/{item}";
                }
                else
                {
                    likes_ = $"{item}";
                    likes = true;
                }
            }
            return $"{publicacao.IdPublicacao};{publicacao.Imagem};{publicacao.Legenda};{publicacao.IdUsuario};{publicacao.NumeroLikes};{likes_}";
        }
        public void CriarPublicacao(Publicacao publicacao)
        {
            string[] linhas = {Prepare(publicacao)};
            File.AppendAllLines(PATH, linhas);
        }

        public void Curtir(int id)
        {
            throw new System.NotImplementedException();
        }

        public void EditarPublicacao(Publicacao publicacao)
        {
            throw new System.NotImplementedException();
        }

        public void ExcluirPublicacao(int id)
        {
            throw new System.NotImplementedException();
        }

        public void ListarPublicacoes()
        {
            throw new System.NotImplementedException();
        }
    }
}